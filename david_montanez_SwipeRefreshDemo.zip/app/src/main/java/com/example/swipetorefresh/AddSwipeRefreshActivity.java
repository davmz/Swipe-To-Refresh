package com.example.swipetorefresh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

public class AddSwipeRefreshActivity extends AppCompatActivity {

    private TextView mTextViewRefreshCount;
    private SwipeRefreshLayout swipeRefreshLayout;
    int num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_swipe_refresh);
        setTitle("Adding Swipe-to-Refresh");
    }

    // Action Bar Implementation that is not necessary but will be a cool feature to add
    /**
     * Listen for option item selections so that we receive a notification
     * when the user requests a refresh by selecting the refresh action bar item.
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menu_refresh:
                // Report that the refresh button was successfully clicked/pressed on
                Log.i("RFRSH-MENU", "Refresh menu item selected");

                Toast.makeText(this, "Refresh Clicked", Toast.LENGTH_SHORT).show();
                return true;
        }

        // User didn't trigger a refresh, let the superclass handle this action.
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_refresh, menu);

        return super.onCreateOptionsMenu(menu);
    }
}