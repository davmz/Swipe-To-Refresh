package com.example.swipetorefresh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Swipe-to-Refresh Demo");
    }

    /**
     * Starts the AddSwipeRefreshActivity activity for part #01 of the demo.
     */
    public void addSwipeRefreshActivity(View view) {
        Intent intent = new Intent(MainActivity.this, AddSwipeRefreshActivity.class);
        startActivity(intent);
    }

    /**
     * Starts the RespondRefreshRequestActivity for part #02 of the demo.
     */
    public void respondRefreshActivity(View view) {
        Intent intent = new Intent(MainActivity.this, RespondRefreshRequestActivity.class);
        startActivity(intent);
    }

    /**
     * Starts the AddSwipeRefreshActivity for part #01 of the demo.
     */
    public void respondRefreshTimerActivity(View view) {
        Intent intent = new Intent(MainActivity.this, RespondRefreshTimerActivity.class);
        startActivity(intent);
    }

    /**
     * Starts the ClassDemoActivity for part #01 of the demo.
     */
    public void classDemoActivity(View view) {
        Intent intent = new Intent(MainActivity.this, ClassDemoActivity.class);
        startActivity(intent);
    }
}