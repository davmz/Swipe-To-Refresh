package com.example.swipetorefresh;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class ClassDemoActivity extends AppCompatActivity {

    private Button mButtonPressMe;
    private TextView mTextViewRefreshCount;
    private SwipeRefreshLayout swipeRefreshLayout;

    int num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_demo);
        setTitle("Class Demo");

        mButtonPressMe = findViewById(R.id.btnPressMe);
        swipeRefreshLayout = findViewById(R.id.slRefresh);
        mTextViewRefreshCount = findViewById(R.id.tvRefreshCount);

        /**
         * Sets up a SwipeRefreshLayout.OnRefreshListener that is invoked when the user
         * performs a swipe-to-refresh gesture.
         */
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // This method performs the actual data-refresh operation.
                // The method calls setRefreshing(false) when it's finished.
                applicationUpdate();
            }
        });
    }

    /**
     * Anything here that you want to update that is related to your activity.
     */
    public void applicationUpdate() {
//        try {
//            // Update Refresh Count
//            refreshCount();
//
//            // Disables the refresh state
//            swipeRefreshLayout.setRefreshing(false);
//        } catch(Exception e) {
//            // Any error with updating your activity/application do stuff here...
//            Log.d("UPD-ERROR-MSG", "Exception Message: " + e.getMessage());
//            Log.d("UPD-ERROR-CAUSE", "Exception Cause: " + e.getCause());
//
//            Toast.makeText(ClassDemoActivity.this, "Activity failed to reload/update", Toast.LENGTH_SHORT).show();
//        }
    }

    private void refreshCount() {
//        num++;
//        mTextViewRefreshCount.setText("Refresh Count: " + num);
    }
}