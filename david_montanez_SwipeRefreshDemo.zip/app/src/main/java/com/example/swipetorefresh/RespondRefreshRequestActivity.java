package com.example.swipetorefresh;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class RespondRefreshRequestActivity extends AppCompatActivity {

    private Button mButtonPressMe;
    private TextView mTextViewRefreshCount;
    private SwipeRefreshLayout swipeRefreshLayout;

    int num = 0,
        pos = 0;

    int[] colors = {Color.RED, Color.YELLOW, Color.GREEN, Color.MAGENTA};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_respond_refresh_request);
        setTitle("Respond to a Refresh Request");

        mButtonPressMe = findViewById(R.id.btnPressMe);
        swipeRefreshLayout = findViewById(R.id.slRefresh);
        mTextViewRefreshCount = findViewById(R.id.tvRefreshCount);

        /**
         * Sets up a SwipeRefreshLayout.OnRefreshListener that is invoked when the user
         * performs a swipe-to-refresh gesture.
         */
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                Log.i("RFRSH", "onRefresh called from SwipeRefreshLayout");

                // Setting up spinner color and size of swipeRefresh spinner element
                swipeRefreshLayout.setColorSchemeColors(getResources().getColor(R.color.purple_200));
                swipeRefreshLayout.setSize(SwipeRefreshLayout.LARGE);

                // This method performs the actual data-refresh operation.
                // The method calls setRefreshing(false) when it's finished.
                applicationUpdate();
            }
        });
    }

    /**
     * Listen for option item selections so that we receive a notification
     * when the user requests a refresh by selecting the refresh action bar item.
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menu_refresh:
                // Report that the refresh button was successfully clicked/pressed on
                Log.i("RFRSH-MENU", "Refresh menu item selected");

                // Signal SwipeRefreshLayout to start the progress indicator
                swipeRefreshLayout.setRefreshing(true);

                // Start the refresh background task.
                // This This method calls setRefreshing(false) when it's finished.
                applicationUpdate();

                return true;
        }

        // User didn't trigger a refresh, let the superclass handle this action.
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_refresh, menu);

        return super.onCreateOptionsMenu(menu);
    }

    /**
     * Anything here that you want to update that is related to your activity.
     */
    public void applicationUpdate() {
        try {
            refreshCount();
            pressMe();

            Toast.makeText(RespondRefreshRequestActivity.this, "Refreshed", Toast.LENGTH_SHORT).show();

            // Disables the refresh state
            swipeRefreshLayout.setRefreshing(false);
        } catch(Exception e) {
            // Any error with updating your activity/application do stuff here...
            Log.d("UPD-ERROR-MSG", "Exception Message: " + e.getMessage());
            Log.d("UPD-ERROR-CAUSE", "Exception Cause: " + e.getCause());

            Toast.makeText(RespondRefreshRequestActivity.this, "Activity failed to reload/update", Toast.LENGTH_SHORT).show();
        }
    }

    private void pressMe() {
        mButtonPressMe.setTextColor(colors[pos%colors.length]);
        pos++;
    }

    private void refreshCount() {
        num++;
        mTextViewRefreshCount.setText("Refresh Count: " + num);
    }
}